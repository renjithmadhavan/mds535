dataDir =/home/ubuntu/zookeeper-3.4.6/data
JAVA_HOME="/usr/lib/jvm/java-1.7.0-openjdk-amd64"
export JAVA_HOME
/home/ubuntu/zookeeper-3.4.6/bin/zkServer.sh  start
