#!/bin/bash

sudo apt-get install unzip
sudo apt-get update --fix-missing
sudo apt-get install openjdk-7-jdk
sudo apt-get install uuid-dev
sudo apt-get install dos2unix
sudo apt-get install libtool git
sudo apt-get update
sudo apt-get g++
sudo apt-get install make
sudo apt-get install git
sudo apt-get install libtool
sudo apt-get install autoconf
sudo apt-get install build-essential
sudo apt-get install pkg-config
sudo apt-get install uuid-dev
sudo apt-get install maven


wget   http://apache.arvixe.com/zookeeper/zookeeper-3.4.6/zookeeper-3.4.6.tar.gz
gzip -d  zookeeper-3.4.6.tar.gz
tar -xf zookeeper-3.4.6.tar

curl http://pkgconfig.freedesktop.org/releases/pkg-config-0.28.tar.gz -o pkgconfig.tgz
tar -zxf pkgconfig.tgz
cd pkg-config-0.28
./configure --with-internal-glib
make install

cd /home/ubuntu
wget http://download.zeromq.org/zeromq-2.1.7.tar.gz
tar -xzf zeromq-2.1.7.tar.gz
cd zeromq-2.1.7
./configure
make
sudo make install

cd /home/ubuntu
git clone https://github.com/nathanmarz/jzmq.git
cd jzmq
sed -i 's/classdist_noinst.stamp/classnoinst.stamp/g' src/Makefile.am
./autogen.sh
export LD_LIBRARY_PATH=/home/ubuntu/zeromq-2.1.7/lib
./configure  --with-zeromq=/home/ubuntu/zeromq-2.1.7
make
sudo make install


wget   http://apache.arvixe.com/storm/apache-storm-0.9.5/apache-storm-0.9.5.tar.gz
tar -xzf  apache-storm-0.9.5.tar.gz

#copy over yaml file

gzip -d  apache-storm-0.9.5.tar.gz wget https://github.com/xetorthio/getting-started-with-storm/archive/master.zip
unzip  master.zip

