#!/bin/bash

sudo apt-get install unzip
sudo apt-get update --fix-missing
sudo apt-get install openjdk-7-jdk
sudo apt-get install uuid-dev
sudo apt-get install dos2unix

wget   http://apache.arvixe.com/zookeeper/zookeeper-3.4.6/zookeeper-3.4.6.tar.gz
gzip -d  zookeeper-3.4.6.tar.gz
tar -xf zookeeper-3.4.6.tar
