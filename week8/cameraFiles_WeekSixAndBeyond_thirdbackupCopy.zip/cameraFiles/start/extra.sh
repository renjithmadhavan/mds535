

mkdir /home/ubuntu/spark-1.2.0-bin-hadoop1/src
mkdir /home/ubuntu/spark-1.2.0-bin-hadoop1/src/main
mkdir /home/ubuntu/spark-1.2.0-bin-hadoop1/src/main/scala
export JAVA_HOME=/usr/
export HADOOP_PREFIX=/home/ubuntu/hadoop-1.2.1
export HADOOP_CONF_DIR=$HADOOP_PREFIX/conf
export PATH=$HADOOP_PREFIX/bin:$PATH
export HIVE_HOME=/home/ubuntu/hive-0.12.0-bin
export SPARK_HOME=/home/ubuntu/spark-0.9.0-incubating-bin-hadoop1
