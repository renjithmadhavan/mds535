wget http://kdd.ics.uci.edu/databases/reuters21578/reuters21578.tar.gz 
tar -xvf reuters21578.tar.gz.1  -C $WORK_DIR/reuters-sgm