mkdir /home/ubuntu/kmeans/reuters-kmeans/clusteredPoints
