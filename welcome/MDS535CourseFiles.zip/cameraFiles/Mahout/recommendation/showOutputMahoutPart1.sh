python show_recommendations2.py  4 u.data u.item  /home/ubuntu/ml-100k/output/part-r-00000
