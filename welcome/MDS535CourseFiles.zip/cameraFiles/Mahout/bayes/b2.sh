hadoop fs -text $WORK_DIR/20news-seq/part-m-000000 | more
