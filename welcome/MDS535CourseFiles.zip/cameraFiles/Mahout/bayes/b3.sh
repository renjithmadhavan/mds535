mahout seq2sparse -i ${WORK_DIR}/20news-seq  -o  ${WORK_DIR}/20news-vectors3  -lnorm -nv  -wt  tfidf 
