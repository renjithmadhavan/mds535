mahout testnb -i   ${WORK_DIR}/20news-test-vectors  -m ${WORK_DIR}/model  -l ${WORK_DIR}/labelindex\  -ow -o ${WORK_DIR}/20news-testing
