mahout seq2sparse -i $WORK_DIR/reuters-out-seqdir  -o $WORK_DIR/reuters-out-seqdir-sparse-kmeans --maxDFPercent 85 --namedVector
