"just a bunch bunch bunch of data" 
