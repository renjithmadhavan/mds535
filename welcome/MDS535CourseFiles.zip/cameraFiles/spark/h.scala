var myVal = �hello scala�;
println(myVal)
