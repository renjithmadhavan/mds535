hadoop jar hadoop-1.2.1/hadoop-examples-1.2.1.jar  wordcount input.txt  output
