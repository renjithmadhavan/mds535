hadoop jar hadoop-1.2.1/hadoop-examples-1.2.1.jar  pi 4 1000
